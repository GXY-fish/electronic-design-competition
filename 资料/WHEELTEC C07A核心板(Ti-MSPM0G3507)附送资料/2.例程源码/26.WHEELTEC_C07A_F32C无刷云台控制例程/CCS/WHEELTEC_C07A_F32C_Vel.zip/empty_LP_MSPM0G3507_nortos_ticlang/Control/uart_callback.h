#ifndef _UART_CALLBACK_H_
#define _UART_CALLBACK_H_
#include "board.h"

extern int Motor1_Speed, Motor2_Speed, motor1_Current_Speed, motor2_Current_Speed;

void usart1_send(u8 data);
void USART1_SEND(u8 *data, u8 len);
void uart1_send_data(uint8_t data);
void uart1_send_SendArray(uint8_t *data, uint8_t len);
u8 BCC_Sum1(u8 *usart_data, unsigned char Count_Number);

#endif
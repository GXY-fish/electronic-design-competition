################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Hardware/bsp_key.c \
../Hardware/gimbal.c 

C_DEPS += \
./Hardware/bsp_key.d \
./Hardware/gimbal.d 

OBJS += \
./Hardware/bsp_key.o \
./Hardware/gimbal.o 

OBJS__QUOTED += \
"Hardware\bsp_key.o" \
"Hardware\gimbal.o" 

C_DEPS__QUOTED += \
"Hardware\bsp_key.d" \
"Hardware\gimbal.d" 

C_SRCS__QUOTED += \
"../Hardware/bsp_key.c" \
"../Hardware/gimbal.c" 



/*
 * Copyright (c) 2021, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "ti_msp_dl_config.h"
#include "board.h"
#include "oled.h"
#include "menu.h"
#include <stdio.h>
#include "MPU6050.h"
#include "bsp_siic.h"
char buf[20];
int menu; 
int main(void)
{
    SYSCFG_DL_init();
	pIICInterface_t siic = &User_sIICDev;
	siic->init();
	NVIC_EnableIRQ(MPU6050_INT_IRQN);
	MPU6050_initialize();           //MPU6050��ʼ��	
	DMP_Init();                     //��ʼ��DMP 
	delay_ms(10);    
	OLED_Init();
	OLED_Clear();
    while (1) {
//         menu = menu1();                   //����һ���˵������������ѡ��
//         if(menu==1) menu2();      //�����˵�
//         if(menu==2) menu3();     //�����˵�
//         if(menu==3) menu4(); //�����˵� 
//         if(menu==4) menu5();
//		printf("Pitch:%.2lf\tRoll:%.2lf\tYaw:%.2lf\r\n",mpu6050.pitch,mpu6050.roll,mpu6050.yaw);
		sprintf(buf,"pich:%.2f",mpu6050.pitch);
		OLED_ShowString(0,0,(uint8_t *)buf,16,1);
		sprintf(buf,"roll:%.2f",mpu6050.roll);
		OLED_ShowString(0,16,(uint8_t *)buf,16,1);
		sprintf(buf," yaw:%.2f",mpu6050.yaw);
		OLED_ShowString(0,32,(uint8_t *)buf,16,1);
		OLED_Refresh();
		delay_ms(1);
		
    }
}
//�ⲿ�ж�  dmp�������
void GROUP1_IRQHandler(void)//Group1���жϷ�����
{
	uint32_t portE2_intp = DL_GPIO_getEnabledInterruptStatus(MPU6050_PORT,MPU6050_INT_PIN_PIN);

	//MPU6050�½����ж�,Ƶ�ʿ���ͨ��DMP����,Ĭ��200Hz
	if( (portE2_intp&MPU6050_INT_PIN_PIN)==MPU6050_INT_PIN_PIN )
	{
		Read_DMP();
		mpu6050.pitch = Roll;
		mpu6050.roll = Pitch;
		mpu6050.yaw = Yaw;
		mpu6050.gyro.x=gyro[0];
		mpu6050.gyro.y=gyro[1];
		mpu6050.gyro.z=gyro[2];
		mpu6050.accel.x=accel[0];
		mpu6050.accel.y=accel[0];
		mpu6050.accel.z=accel[0];
		DL_GPIO_clearInterruptStatus(MPU6050_PORT,MPU6050_INT_PIN_PIN);
	}
}
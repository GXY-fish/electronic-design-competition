#ifndef __BOARD_H__
#define __BOARD_H__

#include "ti_msp_dl_config.h"
#include <stdint.h>

#include "stdio.h"

#include "ti_msp_dl_config.h"

//���⴮��printf
#include <stdarg.h>
#include <stdio.h>
#include <string.h>

//Systick������ֵ,24λ
#define SysTickMAX_COUNT 0xFFFFFF

//Systick����Ƶ��
#define SysTickFre 80000000

//��systick�ļ���ֵת��Ϊ�����ʱ�䵥λ
#define SysTick_MS(x)  ((SysTickFre/1000U)*(uint32_t)(x))
#define SysTick_US(x)  ((SysTickFre/1000000U)*(uint32_t)(x))

void delay_us(unsigned long __us);
void delay_ms(unsigned long ms);
void delay_1us(unsigned long __us);
void delay_1ms(unsigned long ms);

void any_printf(UART_Regs *uart,char *format,...);

#endif
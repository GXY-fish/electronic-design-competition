#include "menu.h"
#include "board.h"

uint8_t display_buf[20];



int i1 = 0;
int i2 = 0;


/**********************************************************

                     ����Ϊһ���˵�

**********************************************************/
int menu1()           
{
	int flag=1; 
   //��¼���ѡ��
      OLED_ShowString(12,0,(uint8_t *)"1.mode1",16,1);
      OLED_ShowString(12,16,(uint8_t *)"2.mode2",16,1);
      OLED_ShowString(12,32,(uint8_t *)"3.mode3",16,1);
      OLED_ShowString(12,48,(uint8_t *)"4.mode4",16,1);
           OLED_Refresh();
	while(1)
	{


		if(key0==0)       //***��һ��***
		{		
			delay_ms(1);	  //����
			while(key0==0); //���º����֣���ͣ����
			delay_ms(1);	  //����
			flag++;
			if(flag==5) flag=1;			
		}
		
		if(key1==0)       //***ȷ��***
		{
			delay_ms(1);	  //����
			while(key1==0); //���º����֣���ͣ����
			delay_ms(1);	  //����			
			OLED_Clear();   //����
			return(flag);   //�������ѡ��
		}
		
            switch(flag)      //����ƶ�
            {
               case 1:
               {
                  OLED_ShowString(0,16,(uint8_t *)" ",16,1);
                  OLED_ShowString(0,32,(uint8_t *)" ",16,1);
                  OLED_ShowString(0,48,(uint8_t *)" ",16,1);
                  OLED_ShowString(0,0,(uint8_t *)"*",16,1);
                   OLED_Refresh();

               }break;
               case 2:
               {
                  OLED_ShowString(0,0,(uint8_t *)" ",16,1);
                  OLED_ShowString(0,32,(uint8_t *)" ",16,1);
                  OLED_ShowString(0,48,(uint8_t *)" ",16,1);
                  OLED_ShowString(0,16,(uint8_t *)"*",16,1);
                   OLED_Refresh();

               }break;
               case 3:
               {
                  OLED_ShowString(0,0,(uint8_t *)" ",16,1);
                  OLED_ShowString(0,16,(uint8_t *)" ",16,1);
                  OLED_ShowString(0,48,(uint8_t *)" ",16,1);
                  OLED_ShowString(0,32,(uint8_t *)"*",16,1);	
                   OLED_Refresh();

                  
               }break;
               case 4:
               {
                  OLED_ShowString(0,0,(uint8_t *)" ",16,1);
                  OLED_ShowString(0,16,(uint8_t *)" ",16,1);
                  OLED_ShowString(0,32,(uint8_t *)" ",16,1);
                  OLED_ShowString(0,48,(uint8_t *)"*",16,1);		
                     OLED_Refresh();
                  
               }break;
            }		
		
	}
}

/**********************************************************

                     ����Ϊ�����˵�

**********************************************************/
int menu2()
{
//   int i=0;
//   int i1 = 0;
      OLED_ShowString(0,0,(uint8_t *)"mode1",16,1);
      OLED_Refresh();   
   	while(1)
{

      if( key1==0) 
  { 
     delay_ms(1);//����
     while( key1==0) ;
     delay_ms(1);//����
     i1=!i1;
  }

    if(i1==1) 
  {

      OLED_ShowString(0,16,(uint8_t *)"start",16,1);   
      OLED_Refresh();     

     
     
     
     
  }
  else if(i1==0)
  {

      OLED_ShowString(0,16,(uint8_t *)"stop  ",16,1);   
      OLED_Refresh(); 
     
     
     
     
 
  }    
  
		if(key2 == 0)//***����***
		{
			delay_ms(1);	    //����
			while(key2 == 0); //���º����֣���ͣ����
			delay_ms(1);	    //����
			OLED_Clear();
			return 0;
		}


   }
}



int menu3()
{
//   uint8_t i=0;
   OLED_ShowString(0,0,(uint8_t *)"mode2",16,1);
   
   	while(1)
	{
            if( key1 == 0) 
        {
           delay_ms(1);//����
           while( key1 == 0) ;
           delay_ms(1);//����
           i2=!i2;
        }
          if(i2==1) 
        {
      OLED_ShowString(0,16,(uint8_t *)"start",16,1);   
      OLED_Refresh();   
		Set_Pwm(50,50);			

        }
        else 
        {
      OLED_ShowString(0,16,(uint8_t *)"stop  ",16,1);   
      OLED_Refresh();
			Set_Pwm(-50,-50);
        }    
   
		if(key2 == 0)//***����***
		{
			delay_ms(1);	    //����
			while(key2 == 0); //���º����֣���ͣ����
			delay_ms(1);	    //����
			OLED_Clear();
			return 0;
		}

   }
}

int menu4()
{
   uint8_t i=0;
      OLED_ShowString(0,0,(uint8_t *)"mode3",16,1);
      OLED_Refresh();   	
   while(1)
	{
       if( key1 == 0) 
        {
           delay_ms(1);//����
           while( key1 == 0) ;
           delay_ms(1);//����
           i=!i;
        }
          if(i==1) 
        {
      OLED_ShowString(0,16,(uint8_t *)"start",16,1);   
      OLED_Refresh();    

        }
        else 
        {
           OLED_ShowString(0,16,(uint8_t *)"stop  ",16,1);
           OLED_Refresh();
       //  Set_Pwm1(0,0);

        }   
   
		if(key2 == 0)//***����***
		{
			delay_ms(1);	    //����
			while(key2 == 0); //���º����֣���ͣ����
			delay_ms(1);	    //����
			OLED_Clear();
			return 0;
		}


   }
}
int menu5()
{
   uint8_t i=0;
      OLED_ShowString(0,0,(uint8_t *)"mode4",16,1);
      OLED_Refresh();   	
   while(1)
	{
     
       if( key1 == 0) 
        {
           delay_ms(1);//����
           while( key1 == 0) ;
           delay_ms(1);//����
           i=!i;
        }
          if(i==1) 
        {
      OLED_ShowString(0,16,(uint8_t *)"start",16,1);   
      OLED_Refresh(); 
        
        }
        else 
        {
            OLED_ShowString(0,16,(uint8_t *)"stop  ",16,1);
            OLED_Refresh();      
        }   
      
		if(key2==0)//***����***
		{
			delay_ms(1);	    //����
			while(key2 == 0); //���º����֣���ͣ����
			delay_ms(1);	    //����
			OLED_Clear();
			return 0;
		}


   }
}
/*
 * Copyright (c) 2021, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "board.h"
__IO uint32_t uwTick = 0;
__IO uint32_t speed_Tick = 0;
__IO uint32_t oled_Tick = 0;

int filt_velocity_r = 0;     //�˲�����ٶ�
int last_filt_velocitya_r = 0;
int filt_velocity_l = 0;     //�˲�����ٶ�
int last_filt_velocitya_l = 0;

int filt_velocity_pingjun = 0;     //�˲�����ٶ�

extern int _encoder_l_count;
extern int _encoder_r_count;
char buf[20];
int menu; 
int main(void)
{
    board_init();
	NVIC_EnableIRQ(GPIOB_INT_IRQn);
	

	
	delay_ms(10);    
	OLED_Init();
	OLED_Clear();
	
//MPU6050��ʼ��		
//	pIICInterface_t siic = &User_sIICDev;
//	siic->init();
//	MPU6050_initialize();           //MPU6050��ʼ��	
//	DMP_Init();    	//��ʼ��DMP 
//ά�س�ʼ��
	jy61pInit();
	delay_ms(10);
	
	Set_Pwm(0,0);
    while (1) {
//         menu = menu1();                   //����һ���˵������������ѡ��
//         if(menu==1) menu2();      //�����˵�
//         if(menu==2) menu3();     //�����˵�
//         if(menu==3) menu4(); //�����˵� 
//         if(menu==4) menu5();
//		printf("Pitch:%.2lf\tRoll:%.2lf\tYaw:%.2lf\r\n",mpu6050.pitch,mpu6050.roll,mpu6050.yaw);
//		sprintf(buf,"pich:%.2f",mpu6050.pitch);
//		OLED_ShowString(0,0,(uint8_t *)buf,16,1);
//		sprintf(buf,"roll:%.2f",mpu6050.roll);
//		OLED_ShowString(0,16,(uint8_t *)buf,16,1);
//		sprintf(buf," yaw:%.2f",mpu6050.yaw);
//		OLED_ShowString(0,32,(uint8_t *)buf,16,1);

//		sprintf(buf," mumber:%d",oled_Tick);
//		OLED_ShowString(0,32,(uint8_t *)buf,16,1);
//		sprintf(buf," L:%d",filt_velocity_l);
//		OLED_ShowString(0,32,(uint8_t *)buf,16,1);
//		sprintf(buf," R:%d",filt_velocity_r);
//		OLED_ShowString(0,48,(uint8_t *)buf,16,1);
		
		Gyro_Struct *JY61P_Data = get_angle();
		
		sprintf(buf," %f",(float)JY61P_Data->x);
		OLED_ShowString(0,0,(uint8_t *)buf,16,1);		
		sprintf(buf," %f",(float)JY61P_Data->y);
		OLED_ShowString(0,16,(uint8_t *)buf,16,1);
		sprintf(buf," %f",(float)JY61P_Data->z);
		OLED_ShowString(0,32,(uint8_t *)buf,16,1);
		
		OLED_Refresh();
//		delay_ms(1);
		
    }
}
//�δ�ʱ���жϷ�����
void SysTick_Handler(void)
{
   float a=0.3;  
    uwTick++;
   
   if(uwTick - speed_Tick>1000){//10ms����һ���ٶ�
      speed_Tick = uwTick;
	   oled_Tick++;
      
//      velocity_r = _encoder_r_count;
//      velocity_l = _encoder_l_count;
      
      filt_velocity_l = a*_encoder_l_count + (1-a)*last_filt_velocitya_l;//���㷨�˲����˴��ٶ�ȡ30%��Ȩ�أ������ٶ�ȡ70%��Ȩ�أ����ٶȸ�ƽ��
      last_filt_velocitya_l = filt_velocity_l; //�˴��ٶȼ�¼Ϊ���ϴ��ٶȡ�
      
      filt_velocity_r = a*_encoder_r_count + (1-a)*last_filt_velocitya_r;//���㷨�˲����˴��ٶ�ȡ30%��Ȩ�أ������ٶ�ȡ70%��Ȩ�أ����ٶȸ�ƽ��
      last_filt_velocitya_r = filt_velocity_r; //�˴��ٶȼ�¼Ϊ���ϴ��ٶȡ�
      
   
      filt_velocity_pingjun += (filt_velocity_l+filt_velocity_r)/2;
      
      _encoder_l_count = 0;
      _encoder_r_count = 0;   
   }
}



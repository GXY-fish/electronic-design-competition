/*
 * Copyright (c) 2021, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "ti_msp_dl_config.h"
#include "board.h"
#include "oled.h"

int main(void)
{
    SYSCFG_DL_init();
	   	delay_ms(500);    
   		OLED_Init();
//   		OLED_DisPlay_On();
   		OLED_Clear();
    while (1) {
		OLED_ShowString(12,0,(uint8_t *)"1.mode1",16,1);
		OLED_ShowString(12,16,(uint8_t *)"2.mode2",16,1);
		OLED_ShowString(12,32,(uint8_t *)"3.mode3",16,1);
		OLED_ShowString(12,48,(uint8_t *)"4.mode4",16,1);
		OLED_Refresh();
		 delay_ms(500);
		OLED_ShowString(12,0,(uint8_t *)"4.mode1",16,1);
		OLED_ShowString(12,16,(uint8_t *)"3.mode2",16,1);
		OLED_ShowString(12,32,(uint8_t *)"2.mode3",16,1);
		OLED_ShowString(12,48,(uint8_t *)"1.mode4",16,1);
		OLED_Refresh();
		delay_ms(500);
		
    }
}
